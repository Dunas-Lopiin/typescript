interface Balance {
    ownerCpf: string
    password: string
    agency: string
    agencyDigit: string
    account: string
    accountDigit: string
}

export { Balance };