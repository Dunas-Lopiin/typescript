interface Withdraw {
    id: string
    ownerCpf: string
    password: string
    agency: string
    agencyDigit: string
    account: string
    accountDigit: string
    value: string
    createdAt: string
}

export { Withdraw };