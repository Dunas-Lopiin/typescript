interface APIResponse{
    data: any
    messages: string[]
}

export {APIResponse};