interface Account{
    id: string
    ownerCpf: string
    password: string
    agency: string
    agencyDigit: string
    account: string
    accountDigit: string
    balance: string
}

export {Account};