interface Owner {
    id: string
    name: string
    email: string
    birthdate: string
    cpf: string
}

export {Owner};